This model's licence is Attribution-NonCommercial 4.0 International (http://creativecommons.org/licenses/by-nc/4.0/)
author:info@bishopx.net